# Actualización de TiendaRopa

Se integró una primera versión de los módulos de operaciones siguiendo el patrón de la referencia SysVentas y conservando el paquete `pe.edu.upeu.tiendaropa`.

## Incluye
- Tab de carrito de venta: seleccionar cliente y producto, agregar/quitar productos, validar stock, calcular subtotal, IGV (18%) y total.
- Confirmación de venta: guarda `venta` y `venta_detalle`, descuenta stock dentro de una transacción y muestra una boleta en pantalla.
- Proveedores: registro básico.
- Compras: registro de compra y detalle de un producto, con aumento de stock.
- Tablas nuevas: `talla`, `proveedor`, `carrito_venta`, `carrito_venta_detalle`, `venta`, `venta_detalle`, `compra`, `compra_detalle`.
- Migración no destructiva de las tallas antiguas a la tabla `talla`, clasificándolas como LETRA o NUMERICA.

## Credenciales iniciales
Usuario: `admin`
Clave: `1234`

## Abrir
Importar la carpeta en IntelliJ como proyecto Maven y ejecutar `pe.edu.upeu.tiendaropa.MainApp`. Se requiere JDK 21.

## Observaciones importantes
- Se conserva temporalmente la columna antigua `producto.talla` para no perder datos al migrar la base H2. La nueva columna `id_talla` y la tabla `talla` quedan creadas y las tallas existentes se migran. El formulario actual de productos aún requiere una adaptación adicional para seleccionar `Talla` desde un ComboBox y guardar su `id_talla`; no se debe eliminar la columna antigua hasta comprobar esa migración en tu instalación.
- La boleta se muestra en pantalla; impresión PDF/térmica no está implementada.
- Los movimientos usan usuario con ID 1 (usuario inicial admin); si cambias el usuario inicial, habrá que resolver el ID de sesión dinámicamente.
- No se ejecutó una compilación Maven en este entorno porque Maven no está instalado. Revisa la compilación en IntelliJ antes de presentar.
- Haz una copia de `data/tiendaropa.mv.db` antes de abrir la versión actualizada por primera vez.
