# Sistema de Gestión - Tienda de Ropa

Proyecto académico de Programación Orientada a Objetos.

## Tecnologías
- Java 21
- JavaFX 21
- Maven
- FXML
- Colecciones `ArrayList`

## Casos de gestión
1. Categoría
2. Marca
3. Producto
4. Cliente

## Arquitectura

Model -> Repository -> Service -> Controller -> View

Los repositorios trabajan en memoria con `ArrayList`; no se utiliza una base de datos.

## Conceptos POO aplicados
- Encapsulamiento: atributos privados y métodos de acceso.
- Abstracción: interfaces genéricas de repositorio y servicio.
- Herencia: repositorios y servicios concretos extienden clases base.
- Polimorfismo: los controladores trabajan con interfaces de servicio.
- Asociación: Producto se relaciona con Categoria y Marca.

## Ejecutar

Desde IntelliJ IDEA:
1. Abrir el proyecto como proyecto Maven.
2. Esperar a que Maven descargue las dependencias.
3. Ejecutar `MainApp`.

Desde terminal:

```bash
mvn javafx:run
```
