package pe.edu.upeu.tiendaropa.service;

import pe.edu.upeu.tiendaropa.model.Marca;
import pe.edu.upeu.tiendaropa.repository.MarcaRepository;

public class MarcaService extends CrudGenericoServiceImp<Marca, Long> {
    public MarcaService(MarcaRepository repository) {
        super(repository);
    }
}
