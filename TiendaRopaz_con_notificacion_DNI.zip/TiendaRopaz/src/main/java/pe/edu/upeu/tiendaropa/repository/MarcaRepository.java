package pe.edu.upeu.tiendaropa.repository;

import pe.edu.upeu.tiendaropa.config.DatabaseConfig;
import pe.edu.upeu.tiendaropa.model.Marca;
import java.sql.*; import java.util.ArrayList; import java.util.List;

public class MarcaRepository implements ICrudGenericoRepository<Marca, Long> {
    @Override public Marca save(Marca m){String sql="INSERT INTO marca(nombre,pais_origen) VALUES(?,?)";try(Connection c=DatabaseConfig.getConnection();PreparedStatement p=c.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS)){p.setString(1,m.getNombre());p.setString(2,m.getPaisOrigen());p.executeUpdate();try(ResultSet k=p.getGeneratedKeys()){if(k.next())m.setId(k.getLong(1));}return m;}catch(SQLException e){throw err("guardar marca",e);}}
    @Override public Marca update(Marca m){try(Connection c=DatabaseConfig.getConnection();PreparedStatement p=c.prepareStatement("UPDATE marca SET nombre=?,pais_origen=? WHERE id=?")){p.setString(1,m.getNombre());p.setString(2,m.getPaisOrigen());p.setLong(3,m.getId());int filas=p.executeUpdate();if(filas==0)throw new IllegalStateException("No existe la marca con ID " + m.getId());return m;}catch(SQLException e){throw err("actualizar marca",e);}}
    @Override public List<Marca> findAll(){List<Marca> l=new ArrayList<>();try(Connection c=DatabaseConfig.getConnection();PreparedStatement p=c.prepareStatement("SELECT * FROM marca ORDER BY id");ResultSet r=p.executeQuery()){while(r.next())l.add(map(r));return l;}catch(SQLException e){throw err("listar marcas",e);}}
    @Override public Marca findById(Long id){try(Connection c=DatabaseConfig.getConnection();PreparedStatement p=c.prepareStatement("SELECT * FROM marca WHERE id=?")){p.setLong(1,id);try(ResultSet r=p.executeQuery()){return r.next()?map(r):null;}}catch(SQLException e){throw err("buscar marca",e);}}
    @Override public void delete(Long id){try(Connection c=DatabaseConfig.getConnection();PreparedStatement p=c.prepareStatement("DELETE FROM marca WHERE id=?")){p.setLong(1,id);p.executeUpdate();}catch(SQLException e){throw err("eliminar marca (comprueba que no tenga productos asociados)",e);}}
    private Marca map(ResultSet r)throws SQLException{return new Marca(r.getLong("id"),r.getString("nombre"),r.getString("pais_origen"));}
    private RuntimeException err(String op,SQLException e){return new IllegalStateException("Error al "+op+": "+e.getMessage(),e);}
}
