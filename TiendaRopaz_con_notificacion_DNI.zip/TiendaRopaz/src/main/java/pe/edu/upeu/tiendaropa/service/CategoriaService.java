package pe.edu.upeu.tiendaropa.service;

import pe.edu.upeu.tiendaropa.model.Categoria;
import pe.edu.upeu.tiendaropa.repository.CategoriaRepository;

public class CategoriaService extends CrudGenericoServiceImp<Categoria, Long> {
    public CategoriaService(CategoriaRepository repository) {
        super(repository);
    }
}
