package pe.edu.upeu.tiendaropa.controller;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import pe.edu.upeu.tiendaropa.config.AppContext;
import pe.edu.upeu.tiendaropa.model.Categoria;

public class CategoriaController {
    @FXML private TextField txtNombre;
    @FXML private TextField txtDescripcion;
    @FXML private TableView<Categoria> tabla;
    @FXML private TableColumn<Categoria, Number> colId;
    @FXML private TableColumn<Categoria, String> colNombre;
    @FXML private TableColumn<Categoria, String> colDescripcion;

    // Guarda el ID real del registro que se está editando.
    // Así, Editar nunca crea un registro nuevo.
    private Long idEditando = null;

    @FXML public void initialize() {
        colId.setCellValueFactory(c -> new javafx.beans.property.SimpleLongProperty(c.getValue().getId()));
        colNombre.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(c.getValue().getNombre()));
        colDescripcion.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(c.getValue().getDescripcion()));
        cargar();
    }

    @FXML public void guardar() {
        if (idEditando != null) {
            alerta("Está editando una categoría. Presione Editar para guardar los cambios.");
            return;
        }
        if (txtNombre.getText().isBlank()) {
            alerta("El nombre es obligatorio.");
            return;
        }
        AppContext.categoriaService().save(
                new Categoria(null, txtNombre.getText().trim(), txtDescripcion.getText().trim())
        );
        limpiar();
        cargar();
    }

    @FXML public void editar() {
        if (idEditando == null) { alerta("Seleccione una categoría para editar."); return; }
        if (txtNombre.getText().isBlank()) { alerta("El nombre es obligatorio."); return; }

        Categoria c = new Categoria(
                idEditando,
                txtNombre.getText().trim(),
                txtDescripcion.getText().trim()
        );
        AppContext.categoriaService().update(c);
        alerta("Categoría actualizada correctamente.");
        limpiar();
        cargar();
    }

    @FXML public void eliminar() {
        Categoria c = tabla.getSelectionModel().getSelectedItem();
        if (c == null) { alerta("Seleccione una categoría."); return; }
        AppContext.categoriaService().delete(c.getId());
        limpiar();
        cargar();
    }

    @FXML public void seleccionar() {
        Categoria c = tabla.getSelectionModel().getSelectedItem();
        if (c != null) {
            idEditando = c.getId();
            txtNombre.setText(c.getNombre());
            txtDescripcion.setText(c.getDescripcion());
        }
    }

    @FXML public void limpiar() {
        idEditando = null;
        txtNombre.clear();
        txtDescripcion.clear();
        tabla.getSelectionModel().clearSelection();
    }

    private void cargar() {
        tabla.setItems(FXCollections.observableArrayList(AppContext.categoriaService().findAll()));
    }

    private void alerta(String mensaje) {
        new Alert(Alert.AlertType.WARNING, mensaje, ButtonType.OK).showAndWait();
    }
}
