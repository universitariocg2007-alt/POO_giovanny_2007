package pe.edu.upeu.tiendaropa.controller;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import pe.edu.upeu.tiendaropa.config.AppContext;
import pe.edu.upeu.tiendaropa.model.Marca;

public class MarcaController {
    @FXML private TextField txtNombre;
    @FXML private TextField txtPais;
    @FXML private TableView<Marca> tabla;
    @FXML private TableColumn<Marca, Number> colId;
    @FXML private TableColumn<Marca, String> colNombre;
    @FXML private TableColumn<Marca, String> colPais;

    private Long idEditando = null;

    @FXML public void initialize() {
        colId.setCellValueFactory(c -> new javafx.beans.property.SimpleLongProperty(c.getValue().getId()));
        colNombre.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(c.getValue().getNombre()));
        colPais.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(c.getValue().getPaisOrigen()));
        cargar();
    }

    @FXML public void guardar() {
        if (idEditando != null) {
            alerta("Está editando una marca. Presione Editar para guardar los cambios.");
            return;
        }
        if (txtNombre.getText().isBlank()) { alerta("El nombre es obligatorio."); return; }
        AppContext.marcaService().save(new Marca(null, txtNombre.getText().trim(), txtPais.getText().trim()));
        limpiar();
        cargar();
    }

    @FXML public void editar() {
        if (idEditando == null) { alerta("Seleccione una marca para editar."); return; }
        if (txtNombre.getText().isBlank()) { alerta("El nombre es obligatorio."); return; }

        Marca m = new Marca(idEditando, txtNombre.getText().trim(), txtPais.getText().trim());
        AppContext.marcaService().update(m);
        alerta("Marca actualizada correctamente.");
        limpiar();
        cargar();
    }

    @FXML public void eliminar() {
        Marca m = tabla.getSelectionModel().getSelectedItem();
        if (m == null) { alerta("Seleccione una marca."); return; }
        AppContext.marcaService().delete(m.getId());
        limpiar();
        cargar();
    }

    @FXML public void seleccionar() {
        Marca m = tabla.getSelectionModel().getSelectedItem();
        if (m != null) {
            idEditando = m.getId();
            txtNombre.setText(m.getNombre());
            txtPais.setText(m.getPaisOrigen());
        }
    }

    @FXML public void limpiar() {
        idEditando = null;
        txtNombre.clear();
        txtPais.clear();
        tabla.getSelectionModel().clearSelection();
    }

    private void cargar() {
        tabla.setItems(FXCollections.observableArrayList(AppContext.marcaService().findAll()));
    }

    private void alerta(String mensaje) {
        new Alert(Alert.AlertType.WARNING, mensaje, ButtonType.OK).showAndWait();
    }
}
