package pe.edu.upeu.tiendaropa.service;

import java.util.List;

public interface ICrudGenericoService<T, ID> {
    T save(T entity);
    T update(T entity);
    List<T> findAll();
    T findById(ID id);
    void delete(ID id);
}
