package pe.edu.upeu.tiendaropa.controller;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import pe.edu.upeu.tiendaropa.config.AppContext;
import pe.edu.upeu.tiendaropa.model.*;

public class ProductoController {
    @FXML private TextField txtNombre, txtTalla, txtColor, txtPrecio, txtStock;
    @FXML private ComboBox<Categoria> cbCategoria;
    @FXML private ComboBox<Marca> cbMarca;
    @FXML private TableView<Producto> tabla;
    @FXML private TableColumn<Producto, Number> colId, colPrecio, colStock;
    @FXML private TableColumn<Producto, String> colNombre, colTalla, colColor, colCategoria, colMarca;

    private Long idEditando = null;

    @FXML public void initialize() {
        colId.setCellValueFactory(c -> new javafx.beans.property.SimpleLongProperty(c.getValue().getId()));
        colNombre.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(c.getValue().getNombre()));
        colTalla.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(c.getValue().getTalla()));
        colColor.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(c.getValue().getColor()));
        colPrecio.setCellValueFactory(c -> new javafx.beans.property.SimpleDoubleProperty(c.getValue().getPrecio()));
        colStock.setCellValueFactory(c -> new javafx.beans.property.SimpleIntegerProperty(c.getValue().getStock()));
        colCategoria.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(
                c.getValue().getCategoria() == null ? "" : c.getValue().getCategoria().getNombre()));
        colMarca.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(
                c.getValue().getMarca() == null ? "" : c.getValue().getMarca().getNombre()));
        cargarCombos();
        cargar();
    }

    private void cargarCombos() {
        cbCategoria.setItems(FXCollections.observableArrayList(AppContext.categoriaService().findAll()));
        cbMarca.setItems(FXCollections.observableArrayList(AppContext.marcaService().findAll()));
    }

    @FXML public void guardar() {
        if (idEditando != null) {
            alerta("Está editando un producto. Presione Editar para guardar los cambios.");
            return;
        }
        try {
            if (txtNombre.getText().isBlank() || cbCategoria.getValue() == null || cbMarca.getValue() == null)
                throw new IllegalArgumentException("Complete nombre, categoría y marca.");
            double precio = Double.parseDouble(txtPrecio.getText());
            int stock = Integer.parseInt(txtStock.getText());
            if (precio < 0 || stock < 0) throw new IllegalArgumentException("Precio y stock no pueden ser negativos.");

            Producto p = new Producto(null, txtNombre.getText().trim(), txtTalla.getText().trim(), txtColor.getText().trim(),
                    precio, stock, cbCategoria.getValue(), cbMarca.getValue());
            AppContext.productoService().save(p);
            limpiar();
            cargar();
        } catch (NumberFormatException e) {
            alerta("Precio y stock deben ser números válidos.");
        } catch (IllegalArgumentException e) {
            alerta(e.getMessage());
        }
    }

    @FXML public void editar() {
        if (idEditando == null) { alerta("Seleccione un producto para editar."); return; }
        try {
            if (txtNombre.getText().isBlank() || cbCategoria.getValue() == null || cbMarca.getValue() == null)
                throw new IllegalArgumentException("Complete nombre, categoría y marca.");

            double precio = Double.parseDouble(txtPrecio.getText());
            int stock = Integer.parseInt(txtStock.getText());
            if (precio < 0 || stock < 0) throw new IllegalArgumentException("Precio y stock no pueden ser negativos.");

            Producto p = new Producto(idEditando,
                    txtNombre.getText().trim(),
                    txtTalla.getText().trim(),
                    txtColor.getText().trim(),
                    precio,
                    stock,
                    cbCategoria.getValue(),
                    cbMarca.getValue());
            AppContext.productoService().update(p);
            alerta("Producto actualizado correctamente.");
            limpiar();
            cargar();
        } catch (NumberFormatException e) {
            alerta("Precio y stock deben ser números válidos.");
        } catch (IllegalArgumentException e) {
            alerta(e.getMessage());
        }
    }

    @FXML public void eliminar() {
        Producto p = tabla.getSelectionModel().getSelectedItem();
        if (p == null) { alerta("Seleccione un producto."); return; }
        AppContext.productoService().delete(p.getId());
        limpiar();
        cargar();
    }

    @FXML public void seleccionar() {
        Producto p = tabla.getSelectionModel().getSelectedItem();
        if (p != null) {
            idEditando = p.getId();
            txtNombre.setText(p.getNombre());
            txtTalla.setText(p.getTalla());
            txtColor.setText(p.getColor());
            txtPrecio.setText(String.valueOf(p.getPrecio()));
            txtStock.setText(String.valueOf(p.getStock()));
            seleccionarCategoria(p.getCategoria());
            seleccionarMarca(p.getMarca());
        }
    }

    private void seleccionarCategoria(Categoria categoria) {
        if (categoria == null) { cbCategoria.getSelectionModel().clearSelection(); return; }
        cbCategoria.getItems().stream()
                .filter(c -> c.getId().equals(categoria.getId()))
                .findFirst()
                .ifPresent(cbCategoria::setValue);
    }

    private void seleccionarMarca(Marca marca) {
        if (marca == null) { cbMarca.getSelectionModel().clearSelection(); return; }
        cbMarca.getItems().stream()
                .filter(m -> m.getId().equals(marca.getId()))
                .findFirst()
                .ifPresent(cbMarca::setValue);
    }

    @FXML public void refrescarCombos() { cargarCombos(); }

    @FXML public void limpiar() {
        idEditando = null;
        txtNombre.clear();
        txtTalla.clear();
        txtColor.clear();
        txtPrecio.clear();
        txtStock.clear();
        cbCategoria.getSelectionModel().clearSelection();
        cbMarca.getSelectionModel().clearSelection();
        tabla.getSelectionModel().clearSelection();
    }

    private void cargar() {
        tabla.setItems(FXCollections.observableArrayList(AppContext.productoService().findAll()));
    }

    private void alerta(String mensaje) {
        new Alert(Alert.AlertType.WARNING, mensaje, ButtonType.OK).showAndWait();
    }
}
