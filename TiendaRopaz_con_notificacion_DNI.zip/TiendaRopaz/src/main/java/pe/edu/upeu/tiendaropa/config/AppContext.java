package pe.edu.upeu.tiendaropa.config;

import pe.edu.upeu.tiendaropa.repository.*;
import pe.edu.upeu.tiendaropa.service.*;

public final class AppContext {

    private static final CategoriaRepository CATEGORIA_REPOSITORY = new CategoriaRepository();
    private static final MarcaRepository MARCA_REPOSITORY = new MarcaRepository();
    private static final ProductoRepository PRODUCTO_REPOSITORY = new ProductoRepository();
    private static final ClienteRepository CLIENTE_REPOSITORY = new ClienteRepository();

    private static final CategoriaService CATEGORIA_SERVICE =
            new CategoriaService(CATEGORIA_REPOSITORY);
    private static final MarcaService MARCA_SERVICE =
            new MarcaService(MARCA_REPOSITORY);
    private static final ProductoService PRODUCTO_SERVICE =
            new ProductoService(PRODUCTO_REPOSITORY);
    private static final ClienteService CLIENTE_SERVICE =
            new ClienteService(CLIENTE_REPOSITORY);

    private AppContext() {}

    public static CategoriaService categoriaService() { return CATEGORIA_SERVICE; }
    public static MarcaService marcaService() { return MARCA_SERVICE; }
    public static ProductoService productoService() { return PRODUCTO_SERVICE; }
    public static ClienteService clienteService() { return CLIENTE_SERVICE; }
}
