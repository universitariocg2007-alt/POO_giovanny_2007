package pe.edu.upeu.tiendaropa.repository;

import pe.edu.upeu.tiendaropa.config.DatabaseConfig;
import pe.edu.upeu.tiendaropa.model.Cliente;
import java.sql.*; import java.util.ArrayList; import java.util.List;

public class ClienteRepository implements ICrudGenericoRepository<Cliente, Long> {
    @Override public Cliente save(Cliente x){String sql="INSERT INTO cliente(dni,nombres,apellidos,telefono,correo) VALUES(?,?,?,?,?)";try(Connection c=DatabaseConfig.getConnection();PreparedStatement p=c.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS)){bind(p,x);p.executeUpdate();try(ResultSet k=p.getGeneratedKeys()){if(k.next())x.setId(k.getLong(1));}return x;}catch(SQLException e){throw err("guardar cliente (verifica que el DNI no esté registrado)",e);}}
    @Override public Cliente update(Cliente x){String sql="UPDATE cliente SET dni=?,nombres=?,apellidos=?,telefono=?,correo=? WHERE id=?";try(Connection c=DatabaseConfig.getConnection();PreparedStatement p=c.prepareStatement(sql)){bind(p,x);p.setLong(6,x.getId());int filas=p.executeUpdate();if(filas==0)throw new IllegalStateException("No existe el cliente con ID " + x.getId());return x;}catch(SQLException e){throw err("actualizar cliente",e);}}
    @Override public List<Cliente> findAll(){List<Cliente> l=new ArrayList<>();try(Connection c=DatabaseConfig.getConnection();PreparedStatement p=c.prepareStatement("SELECT * FROM cliente ORDER BY id");ResultSet r=p.executeQuery()){while(r.next())l.add(map(r));return l;}catch(SQLException e){throw err("listar clientes",e);}}
    @Override public Cliente findById(Long id){try(Connection c=DatabaseConfig.getConnection();PreparedStatement p=c.prepareStatement("SELECT * FROM cliente WHERE id=?")){p.setLong(1,id);try(ResultSet r=p.executeQuery()){return r.next()?map(r):null;}}catch(SQLException e){throw err("buscar cliente",e);}}
    @Override public void delete(Long id){try(Connection c=DatabaseConfig.getConnection();PreparedStatement p=c.prepareStatement("DELETE FROM cliente WHERE id=?")){p.setLong(1,id);p.executeUpdate();}catch(SQLException e){throw err("eliminar cliente",e);}}
    private void bind(PreparedStatement p,Cliente x)throws SQLException{p.setString(1,x.getDni());p.setString(2,x.getNombres());p.setString(3,x.getApellidos());p.setString(4,x.getTelefono());p.setString(5,x.getCorreo());}
    private Cliente map(ResultSet r)throws SQLException{return new Cliente(r.getLong("id"),r.getString("dni"),r.getString("nombres"),r.getString("apellidos"),r.getString("telefono"),r.getString("correo"));}
    private RuntimeException err(String op,SQLException e){return new IllegalStateException("Error al "+op+": "+e.getMessage(),e);}
}
