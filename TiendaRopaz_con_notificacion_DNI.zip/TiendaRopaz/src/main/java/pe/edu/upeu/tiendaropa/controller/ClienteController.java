package pe.edu.upeu.tiendaropa.controller;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import pe.edu.upeu.tiendaropa.config.AppContext;
import pe.edu.upeu.tiendaropa.model.Cliente;

public class ClienteController {
    @FXML private TextField txtDni, txtNombres, txtApellidos, txtTelefono, txtCorreo;
    @FXML private TableView<Cliente> tabla;
    @FXML private TableColumn<Cliente, Number> colId;
    @FXML private TableColumn<Cliente, String> colDni, colNombres, colApellidos, colTelefono, colCorreo;

    private Long idEditando = null;

    @FXML public void initialize() {
        colId.setCellValueFactory(c -> new javafx.beans.property.SimpleLongProperty(c.getValue().getId()));
        colDni.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(c.getValue().getDni()));
        colNombres.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(c.getValue().getNombres()));
        colApellidos.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(c.getValue().getApellidos()));
        colTelefono.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(c.getValue().getTelefono()));
        colCorreo.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(c.getValue().getCorreo()));
        cargar();
    }

    @FXML public void guardar() {
        if (idEditando != null) {
            alerta("Está editando un cliente. Presione Editar para guardar los cambios.");
            return;
        }
        if (txtDni.getText().isBlank() || txtNombres.getText().isBlank()) {
            alerta("DNI y nombres son obligatorios."); return;
        }
        String dni = txtDni.getText().trim();
        if (dniRegistrado(dni, null)) {
            alerta("DNI existente ya registrado en Clientes");
            txtDni.requestFocus();
            txtDni.selectAll();
            return;
        }

        AppContext.clienteService().save(new Cliente(null, dni, txtNombres.getText().trim(),
                txtApellidos.getText().trim(), txtTelefono.getText().trim(), txtCorreo.getText().trim()));

        // Notificación de registro exitoso
        exito("Registrado Correctamente los datos del Cliente");

        limpiar();
        cargar();
    }

    @FXML public void editar() {
        if (idEditando == null) { alerta("Seleccione un cliente para editar."); return; }
        if (txtDni.getText().isBlank() || txtNombres.getText().isBlank()) {
            alerta("DNI y nombres son obligatorios."); return;
        }

        String dni = txtDni.getText().trim();
        if (dniRegistrado(dni, idEditando)) {
            alerta("DNI existente ya registrado en Clientes");
            txtDni.requestFocus();
            txtDni.selectAll();
            return;
        }

        Cliente c = new Cliente(idEditando,
                dni,
                txtNombres.getText().trim(),
                txtApellidos.getText().trim(),
                txtTelefono.getText().trim(),
                txtCorreo.getText().trim());
        AppContext.clienteService().update(c);
        alerta("Cliente actualizado correctamente.");
        limpiar();
        cargar();
    }

    @FXML public void eliminar() {
        Cliente c = tabla.getSelectionModel().getSelectedItem();
        if (c == null) { alerta("Seleccione un cliente."); return; }
        AppContext.clienteService().delete(c.getId());
        limpiar();
        cargar();
    }

    @FXML public void seleccionar() {
        Cliente c = tabla.getSelectionModel().getSelectedItem();
        if (c != null) {
            idEditando = c.getId();
            txtDni.setText(c.getDni());
            txtNombres.setText(c.getNombres());
            txtApellidos.setText(c.getApellidos());
            txtTelefono.setText(c.getTelefono());
            txtCorreo.setText(c.getCorreo());
        }
    }

    @FXML public void limpiar() {
        idEditando = null;
        txtDni.clear();
        txtNombres.clear();
        txtApellidos.clear();
        txtTelefono.clear();
        txtCorreo.clear();
        tabla.getSelectionModel().clearSelection();
    }

    /**
     * Comprueba si el DNI pertenece a otro cliente.
     * Al editar, se excluye el ID del cliente actual para permitir conservar su DNI.
     */
    private boolean dniRegistrado(String dni, Long idExcluir) {
        return AppContext.clienteService().findAll().stream()
                .anyMatch(cliente -> cliente.getDni() != null
                        && cliente.getDni().trim().equalsIgnoreCase(dni)
                        && (idExcluir == null || !cliente.getId().equals(idExcluir)));
    }

    private void cargar() {
        tabla.setItems(FXCollections.observableArrayList(AppContext.clienteService().findAll()));
    }

    private void alerta(String mensaje) {
        Alert alert = new Alert(Alert.AlertType.WARNING, mensaje, ButtonType.OK);
        alert.setTitle("Atención");
        alert.setHeaderText(null);
        alert.showAndWait();
    }

    private void exito(String mensaje) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION, mensaje, ButtonType.OK);
        alert.setTitle("Registro exitoso");
        alert.setHeaderText("¡Cliente registrado correctamente!");
        alert.showAndWait();
    }
}
