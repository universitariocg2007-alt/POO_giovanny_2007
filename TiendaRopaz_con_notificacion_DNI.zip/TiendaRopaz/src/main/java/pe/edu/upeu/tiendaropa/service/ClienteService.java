package pe.edu.upeu.tiendaropa.service;

import pe.edu.upeu.tiendaropa.model.Cliente;
import pe.edu.upeu.tiendaropa.repository.ClienteRepository;

public class ClienteService extends CrudGenericoServiceImp<Cliente, Long> {
    public ClienteService(ClienteRepository repository) {
        super(repository);
    }
}
