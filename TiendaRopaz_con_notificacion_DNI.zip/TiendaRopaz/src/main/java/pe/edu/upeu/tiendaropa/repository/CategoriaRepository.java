package pe.edu.upeu.tiendaropa.repository;

import pe.edu.upeu.tiendaropa.config.DatabaseConfig;
import pe.edu.upeu.tiendaropa.model.Categoria;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CategoriaRepository implements ICrudGenericoRepository<Categoria, Long> {
    @Override public Categoria save(Categoria c) {
        String sql = "INSERT INTO categoria(nombre, descripcion) VALUES (?, ?)";
        try (Connection cn=DatabaseConfig.getConnection(); PreparedStatement ps=cn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1,c.getNombre()); ps.setString(2,c.getDescripcion()); ps.executeUpdate();
            try(ResultSet k=ps.getGeneratedKeys()){if(k.next()) c.setId(k.getLong(1));} return c;
        } catch(SQLException e){throw error("guardar categoría",e);}
    }
    @Override public Categoria update(Categoria c) {
        try(Connection cn=DatabaseConfig.getConnection(); PreparedStatement ps=cn.prepareStatement("UPDATE categoria SET nombre=?, descripcion=? WHERE id=?")) {
            ps.setString(1,c.getNombre()); ps.setString(2,c.getDescripcion()); ps.setLong(3,c.getId()); int filas=ps.executeUpdate(); if(filas==0) throw new IllegalStateException("No existe la categoría con ID " + c.getId()); return c;
        } catch(SQLException e){throw error("actualizar categoría",e);}
    }
    @Override public List<Categoria> findAll(){ List<Categoria> r=new ArrayList<>(); try(Connection cn=DatabaseConfig.getConnection(); PreparedStatement ps=cn.prepareStatement("SELECT * FROM categoria ORDER BY id"); ResultSet rs=ps.executeQuery()){while(rs.next())r.add(map(rs)); return r;}catch(SQLException e){throw error("listar categorías",e);} }
    @Override public Categoria findById(Long id){try(Connection cn=DatabaseConfig.getConnection();PreparedStatement ps=cn.prepareStatement("SELECT * FROM categoria WHERE id=?")){ps.setLong(1,id);try(ResultSet rs=ps.executeQuery()){return rs.next()?map(rs):null;}}catch(SQLException e){throw error("buscar categoría",e);}}
    @Override public void delete(Long id){try(Connection cn=DatabaseConfig.getConnection();PreparedStatement ps=cn.prepareStatement("DELETE FROM categoria WHERE id=?")){ps.setLong(1,id);ps.executeUpdate();}catch(SQLException e){throw error("eliminar categoría (comprueba que no tenga productos asociados)",e);}}
    private Categoria map(ResultSet rs)throws SQLException{return new Categoria(rs.getLong("id"),rs.getString("nombre"),rs.getString("descripcion"));}
    private RuntimeException error(String op,SQLException e){return new IllegalStateException("Error al "+op+": "+e.getMessage(),e);}
}
