package pe.edu.upeu.tiendaropa.repository;

import java.util.List;

public interface ICrudGenericoRepository<T, ID> {
    T save(T entity);
    T update(T entity);
    List<T> findAll();
    T findById(ID id);
    void delete(ID id);
}
