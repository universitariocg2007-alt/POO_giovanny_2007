package pe.edu.upeu.tiendaropa.controller;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TabPane;
import pe.edu.upeu.tiendaropa.config.AppContext;

public class MainController {

    @FXML private TabPane tabPane;
    @FXML private Label lblResumen;

    @FXML
    public void initialize() {
        actualizarResumen();
    }

    @FXML
    public void actualizarResumen() {
        int categorias = AppContext.categoriaService().findAll().size();
        int marcas = AppContext.marcaService().findAll().size();
        int productos = AppContext.productoService().findAll().size();
        int clientes = AppContext.clienteService().findAll().size();

        lblResumen.setText(
                "Registros actuales  |  Categorías: " + categorias +
                "   Marcas: " + marcas +
                "   Productos: " + productos +
                "   Clientes: " + clientes
        );
    }
}
