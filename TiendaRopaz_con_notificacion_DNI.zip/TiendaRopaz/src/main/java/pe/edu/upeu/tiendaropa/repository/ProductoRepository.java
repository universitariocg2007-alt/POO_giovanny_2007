package pe.edu.upeu.tiendaropa.repository;

import pe.edu.upeu.tiendaropa.config.DatabaseConfig;
import pe.edu.upeu.tiendaropa.model.Categoria;
import pe.edu.upeu.tiendaropa.model.Marca;
import pe.edu.upeu.tiendaropa.model.Producto;
import java.sql.*; import java.util.ArrayList; import java.util.List;

public class ProductoRepository implements ICrudGenericoRepository<Producto, Long> {
    private static final String SELECT="SELECT p.*, c.nombre AS categoria_nombre, c.descripcion AS categoria_descripcion, m.nombre AS marca_nombre, m.pais_origen AS marca_pais FROM producto p JOIN categoria c ON c.id=p.categoria_id JOIN marca m ON m.id=p.marca_id";
    @Override public Producto save(Producto x){String sql="INSERT INTO producto(nombre,talla,id_talla,color,precio,stock,categoria_id,marca_id) VALUES(?,?,?,?,?,?,?,?)";try(Connection c=DatabaseConfig.getConnection();PreparedStatement p=c.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS)){bind(p,x);p.executeUpdate();try(ResultSet k=p.getGeneratedKeys()){if(k.next())x.setId(k.getLong(1));}return x;}catch(SQLException e){throw err("guardar producto",e);}}
    @Override public Producto update(Producto x){String sql="UPDATE producto SET nombre=?,talla=?,id_talla=?,color=?,precio=?,stock=?,categoria_id=?,marca_id=? WHERE id=?";try(Connection c=DatabaseConfig.getConnection();PreparedStatement p=c.prepareStatement(sql)){bind(p,x);p.setLong(9,x.getId());int filas=p.executeUpdate();if(filas==0)throw new IllegalStateException("No existe el producto con ID " + x.getId());return x;}catch(SQLException e){throw err("actualizar producto",e);}}
    @Override public List<Producto> findAll(){List<Producto> l=new ArrayList<>();try(Connection c=DatabaseConfig.getConnection();PreparedStatement p=c.prepareStatement(SELECT+" ORDER BY p.id");ResultSet r=p.executeQuery()){while(r.next())l.add(map(r));return l;}catch(SQLException e){throw err("listar productos",e);}}
    @Override public Producto findById(Long id){try(Connection c=DatabaseConfig.getConnection();PreparedStatement p=c.prepareStatement(SELECT+" WHERE p.id=?")){p.setLong(1,id);try(ResultSet r=p.executeQuery()){return r.next()?map(r):null;}}catch(SQLException e){throw err("buscar producto",e);}}
    @Override public void delete(Long id){try(Connection c=DatabaseConfig.getConnection();PreparedStatement p=c.prepareStatement("DELETE FROM producto WHERE id=?")){p.setLong(1,id);p.executeUpdate();}catch(SQLException e){throw err("eliminar producto",e);}}
    private void bind(PreparedStatement p,Producto x)throws SQLException{p.setString(1,x.getNombre());p.setString(2,x.getTalla());p.setNull(3,Types.BIGINT);p.setString(4,x.getColor());p.setDouble(5,x.getPrecio());p.setInt(6,x.getStock());if(x.getCategoria()==null||x.getMarca()==null)throw new IllegalArgumentException("Seleccione categoría y marca.");p.setLong(7,x.getCategoria().getId());p.setLong(8,x.getMarca().getId());}
    private Producto map(ResultSet r)throws SQLException{Categoria c=new Categoria(r.getLong("categoria_id"),r.getString("categoria_nombre"),r.getString("categoria_descripcion"));Marca m=new Marca(r.getLong("marca_id"),r.getString("marca_nombre"),r.getString("marca_pais"));return new Producto(r.getLong("id"),r.getString("nombre"),r.getString("talla"),r.getString("color"),r.getDouble("precio"),r.getInt("stock"),c,m);}
    private RuntimeException err(String op,SQLException e){return new IllegalStateException("Error al "+op+": "+e.getMessage(),e);}
}
