package pe.edu.upeu.tiendaropa.service;

import pe.edu.upeu.tiendaropa.model.Producto;
import pe.edu.upeu.tiendaropa.repository.ProductoRepository;

public class ProductoService extends CrudGenericoServiceImp<Producto, Long> {
    public ProductoService(ProductoRepository repository) {
        super(repository);
    }
}
