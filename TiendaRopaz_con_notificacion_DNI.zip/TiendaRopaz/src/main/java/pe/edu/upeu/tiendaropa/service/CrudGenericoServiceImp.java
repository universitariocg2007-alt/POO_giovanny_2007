package pe.edu.upeu.tiendaropa.service;

import pe.edu.upeu.tiendaropa.repository.ICrudGenericoRepository;
import java.util.List;

public abstract class CrudGenericoServiceImp<T, ID>
        implements ICrudGenericoService<T, ID> {

    protected final ICrudGenericoRepository<T, ID> repository;

    protected CrudGenericoServiceImp(ICrudGenericoRepository<T, ID> repository) {
        this.repository = repository;
    }

    @Override public T save(T entity) { return repository.save(entity); }
    @Override public T update(T entity) { return repository.update(entity); }
    @Override public List<T> findAll() { return repository.findAll(); }
    @Override public T findById(ID id) { return repository.findById(id); }
    @Override public void delete(ID id) { repository.delete(id); }
}
