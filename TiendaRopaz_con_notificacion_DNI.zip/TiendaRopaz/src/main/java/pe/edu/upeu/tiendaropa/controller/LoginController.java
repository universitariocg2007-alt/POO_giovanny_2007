package pe.edu.upeu.tiendaropa.controller;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import pe.edu.upeu.tiendaropa.config.DatabaseConfig;
import pe.edu.upeu.tiendaropa.config.DatabaseConfig;

public class LoginController {

    @FXML
    private TextField txtUsuario;

    @FXML
    private PasswordField txtClave;

    @FXML
    public void ingresar() {

        String usuario = txtUsuario.getText();
        String clave = txtClave.getText();

        if (DatabaseConfig.validarUsuario(usuario, clave)) {

            try {
                FXMLLoader loader = new FXMLLoader(
                        getClass().getResource("/view/MainView.fxml")
                );

                Scene scene = new Scene(loader.load());

                Stage stage = (Stage) txtUsuario.getScene().getWindow();
                stage.setScene(scene);
                stage.setTitle("Sistema de Tienda de Ropa");
                stage.show();

            } catch (Exception e) {
                e.printStackTrace();
            }

        } else {

            Alert alerta = new Alert(Alert.AlertType.ERROR);
            alerta.setTitle("Inicio de sesión");
            alerta.setHeaderText("Acceso denegado");
            alerta.setContentText("Usuario o contraseña incorrectos.");
            alerta.showAndWait();
        }
    }
}