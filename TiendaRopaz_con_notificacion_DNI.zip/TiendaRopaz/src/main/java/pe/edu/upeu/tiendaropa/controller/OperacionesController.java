package pe.edu.upeu.tiendaropa.controller;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import pe.edu.upeu.tiendaropa.config.DatabaseConfig;
import pe.edu.upeu.tiendaropa.config.AppContext;
import pe.edu.upeu.tiendaropa.model.*;
import java.sql.*;
import java.util.*;

public class OperacionesController {
 @FXML private ComboBox<Producto> cbProducto;
 @FXML private ComboBox<Cliente> cbCliente;
 @FXML private ComboBox<String> cbComprobante;
 @FXML private TextField txtCantidad;
 @FXML private TableView<Item> tablaCarrito;
 @FXML private TableColumn<Item,String> colProducto;
 @FXML private TableColumn<Item,Number> colCantidad,colImporte;
 @FXML private Label lblTotal;
 @FXML private TextField txtRuc,txtRazon,txtTelefono,txtCorreo,txtDireccion;
 @FXML private TextField txtTipoCompra,txtSerieCompra,txtNumeroCompra,txtCantidadCompra,txtCostoCompra;
 @FXML private ComboBox<String> cbProveedor;
 @FXML private ComboBox<Producto> cbProductoCompra;
 private final List<Item> carrito=new ArrayList<>();
 private record Item(Producto producto,int cantidad,double precio) { double importe(){return cantidad*precio;} }
 @FXML public void initialize(){
  cargarProductos();
  cbCliente.setItems(FXCollections.observableArrayList(AppContext.clienteService().findAll()));
  cbComprobante.getItems().setAll("BOLETA","FACTURA"); cbComprobante.setValue("BOLETA");
  colProducto.setCellValueFactory(v->new javafx.beans.property.SimpleStringProperty(v.getValue().producto().getNombre()));
  colCantidad.setCellValueFactory(v->new javafx.beans.property.SimpleIntegerProperty(v.getValue().cantidad()));
  colImporte.setCellValueFactory(v->new javafx.beans.property.SimpleDoubleProperty(v.getValue().importe()));
  cargarProveedores(); actualizarTotal();
 }
 @FXML public void agregarCarrito(){try{Producto p=cbProducto.getValue();int n=Integer.parseInt(txtCantidad.getText());if(p==null||n<=0)throw new IllegalArgumentException("Seleccione producto e indique cantidad positiva.");int existente=carrito.stream().filter(i->i.producto().getId().equals(p.getId())).mapToInt(Item::cantidad).sum();if(n+existente>p.getStock())throw new IllegalArgumentException("La cantidad supera el stock disponible.");carrito.add(new Item(p,n,p.getPrecio()));refrescarCarrito();}catch(Exception e){alerta(e.getMessage());}}
 @FXML public void quitarCarrito(){Item i=tablaCarrito.getSelectionModel().getSelectedItem();if(i!=null){carrito.remove(i);refrescarCarrito();}}
 private void refrescarCarrito(){tablaCarrito.setItems(FXCollections.observableArrayList(carrito));actualizarTotal();}
 private double subtotal(){return carrito.stream().mapToDouble(Item::importe).sum();}
 private void actualizarTotal(){double s=subtotal();lblTotal.setText(String.format("Subtotal: S/ %.2f | IGV (18%%): S/ %.2f | Total: S/ %.2f",s,s*.18,s*1.18));}
 @FXML public void confirmarVenta(){
  if(carrito.isEmpty()||cbCliente.getValue()==null){alerta("Agregue productos y seleccione un cliente.");return;}
  StringBuilder boleta=new StringBuilder();
  try(Connection c=DatabaseConfig.getConnection()){
   c.setAutoCommit(false); double sub=subtotal(),igv=sub*.18,total=sub+igv; long ventaId;
   try(PreparedStatement p=c.prepareStatement("INSERT INTO venta(tipo_comprobante,serie,numero,subtotal,igv,total,cliente_id,usuario_id) VALUES(?,?,?,?,?,?,?,?)",Statement.RETURN_GENERATED_KEYS)){
    p.setString(1,cbComprobante.getValue());p.setString(2,cbComprobante.getValue().equals("BOLETA")?"B001":"F001");p.setLong(3,System.currentTimeMillis()%1000000);p.setDouble(4,sub);p.setDouble(5,igv);p.setDouble(6,total);p.setLong(7,cbCliente.getValue().getId());p.setLong(8,1);p.executeUpdate();try(ResultSet k=p.getGeneratedKeys()){k.next();ventaId=k.getLong(1);}}
   for(Item i:carrito){try(PreparedStatement d=c.prepareStatement("INSERT INTO venta_detalle(venta_id,producto_id,cantidad,precio_unitario,subtotal) VALUES(?,?,?,?,?)")){d.setLong(1,ventaId);d.setLong(2,i.producto().getId());d.setInt(3,i.cantidad());d.setDouble(4,i.precio());d.setDouble(5,i.importe());d.executeUpdate();}try(PreparedStatement u=c.prepareStatement("UPDATE producto SET stock=stock-? WHERE id=? AND stock>=?")){u.setInt(1,i.cantidad());u.setLong(2,i.producto().getId());u.setInt(3,i.cantidad());if(u.executeUpdate()!=1)throw new SQLException("Stock insuficiente para "+i.producto().getNombre());}}
   c.commit();
   boleta.append("TIENDA DE ROPA\nCOMPROBANTE: ").append(cbComprobante.getValue()).append(" N° ").append(ventaId).append("\nCliente: ").append(cbCliente.getValue().getNombres()).append(" ").append(cbCliente.getValue().getApellidos()).append("\n--------------------------------\n");for(Item i:carrito)boleta.append(i.producto().getNombre()).append(" x ").append(i.cantidad()).append(" = S/ ").append(String.format("%.2f",i.importe())).append("\n");boleta.append(String.format("\nSubtotal: S/ %.2f\nIGV: S/ %.2f\nTOTAL: S/ %.2f",sub,igv,total));
   TextArea area=new TextArea(boleta.toString());area.setEditable(false);area.setPrefColumnCount(38);area.setPrefRowCount(18);Alert a=new Alert(Alert.AlertType.INFORMATION);a.setTitle("Boleta de venta");a.setHeaderText("Venta registrada correctamente");a.getDialogPane().setContent(area);a.showAndWait();carrito.clear();refrescarCarrito();cargarProductos();
  }catch(Exception e){alerta("No se pudo registrar la venta: "+e.getMessage());}
 }
 @FXML public void guardarProveedor(){try(Connection c=DatabaseConfig.getConnection();PreparedStatement p=c.prepareStatement("INSERT INTO proveedor(ruc,razon_social,telefono,correo,direccion) VALUES(?,?,?,?,?)")){if(txtRazon.getText().isBlank())throw new IllegalArgumentException("Ingrese la razón social.");p.setString(1,txtRuc.getText());p.setString(2,txtRazon.getText());p.setString(3,txtTelefono.getText());p.setString(4,txtCorreo.getText());p.setString(5,txtDireccion.getText());p.executeUpdate();cargarProveedores();alerta("Proveedor registrado.");}catch(Exception e){alerta(e.getMessage());}}
 private void cargarProductos(){
  try {
   List<Producto> productos=AppContext.productoService().findAll();
   cbProducto.setItems(FXCollections.observableArrayList(productos));
   cbProductoCompra.setItems(FXCollections.observableArrayList(productos));
  } catch(Exception e){
   alerta("No se pudieron cargar los productos: "+e.getMessage());
  }
 }
 private void cargarProveedores(){
  try(Connection c=DatabaseConfig.getConnection();Statement s=c.createStatement();ResultSet r=s.executeQuery("SELECT id,razon_social FROM proveedor ORDER BY razon_social")){
   List<String> l=new ArrayList<>(); while(r.next()) l.add(r.getLong(1)+" - "+r.getString(2));
   cbProveedor.setItems(FXCollections.observableArrayList(l));
  } catch(Exception e){ alerta("No se pudieron cargar los proveedores: "+e.getMessage()); }
 }
 @FXML public void registrarCompra(){try{if(cbProveedor.getValue()==null||cbProductoCompra.getValue()==null)throw new IllegalArgumentException("Seleccione proveedor y producto.");int cantidad=Integer.parseInt(txtCantidadCompra.getText());double costo=Double.parseDouble(txtCostoCompra.getText());if(cantidad<=0||costo<0)throw new IllegalArgumentException("Cantidad y costo deben ser válidos.");long proveedor=Long.parseLong(cbProveedor.getValue().split(" - ")[0]);try(Connection c=DatabaseConfig.getConnection()){c.setAutoCommit(false);double sub=cantidad*costo,igv=sub*.18;long id;try(PreparedStatement p=c.prepareStatement("INSERT INTO compra(tipo_comprobante,serie,numero,subtotal,igv,total,proveedor_id,usuario_id) VALUES(?,?,?,?,?,?,?,?)",Statement.RETURN_GENERATED_KEYS)){p.setString(1,txtTipoCompra.getText().isBlank()?"FACTURA":txtTipoCompra.getText());p.setString(2,txtSerieCompra.getText());p.setString(3,txtNumeroCompra.getText());p.setDouble(4,sub);p.setDouble(5,igv);p.setDouble(6,sub+igv);p.setLong(7,proveedor);p.setLong(8,1);p.executeUpdate();try(ResultSet r=p.getGeneratedKeys()){r.next();id=r.getLong(1);}}try(PreparedStatement d=c.prepareStatement("INSERT INTO compra_detalle(compra_id,producto_id,cantidad,precio_unitario,subtotal) VALUES(?,?,?,?,?)")){d.setLong(1,id);d.setLong(2,cbProductoCompra.getValue().getId());d.setInt(3,cantidad);d.setDouble(4,costo);d.setDouble(5,sub);d.executeUpdate();}try(PreparedStatement u=c.prepareStatement("UPDATE producto SET stock=stock+? WHERE id=?")){u.setInt(1,cantidad);u.setLong(2,cbProductoCompra.getValue().getId());u.executeUpdate();}c.commit();}alerta("Compra registrada y stock actualizado.");}catch(Exception e){alerta("No se pudo registrar la compra: "+e.getMessage());}}
 private void alerta(String m){new Alert(Alert.AlertType.INFORMATION,m,ButtonType.OK).showAndWait();}
}
