package pe.edu.upeu.tiendaropa.model;

public class Producto {
    private Long id;
    private String nombre;
    private String talla;
    private String color;
    private double precio;
    private int stock;
    private Categoria categoria;
    private Marca marca;

    public Producto() {}

    public Producto(Long id, String nombre, String talla, String color,
                     double precio, int stock, Categoria categoria, Marca marca) {
        this.id = id;
        this.nombre = nombre;
        this.talla = talla;
        this.color = color;
        this.precio = precio;
        this.stock = stock;
        this.categoria = categoria;
        this.marca = marca;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public String getTalla() { return talla; }
    public void setTalla(String talla) { this.talla = talla; }
    public String getColor() { return color; }
    public void setColor(String color) { this.color = color; }
    public double getPrecio() { return precio; }
    public void setPrecio(double precio) { this.precio = precio; }
    public int getStock() { return stock; }
    public void setStock(int stock) { this.stock = stock; }
    public Categoria getCategoria() { return categoria; }
    public void setCategoria(Categoria categoria) { this.categoria = categoria; }
    public Marca getMarca() { return marca; }
    public void setMarca(Marca marca) { this.marca = marca; }

    @Override public String toString() {
        return nombre + " | Stock: " + stock + " | S/ " + String.format("%.2f", precio);
    }
}
