package pe.edu.upeu.tiendaropa;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import pe.edu.upeu.tiendaropa.config.DatabaseConfig;

public class MainApp extends Application {

    @Override
    public void start(Stage stage) throws Exception {
        DatabaseConfig.initialize();

        FXMLLoader loader = new FXMLLoader(
                MainApp.class.getResource("/view/LoginView.fxml")
        );

        Scene scene = new Scene(loader.load(), 500, 350);

        stage.setTitle("Inicio de Sesión");
        stage.setScene(scene);

        stage.setMinWidth(400);
        stage.setMinHeight(300);

        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}