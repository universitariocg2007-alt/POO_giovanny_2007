module pe.edu.upeu.tiendaropa {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;

    exports pe.edu.upeu.tiendaropa;
    exports pe.edu.upeu.tiendaropa.model;
    exports pe.edu.upeu.tiendaropa.controller;

    opens pe.edu.upeu.tiendaropa.controller to javafx.fxml;
    opens pe.edu.upeu.tiendaropa.model to javafx.base;
}
