# Corrección de Ventas, Compras y Proveedores

Se corrigió el módulo de operaciones para que:

- Ventas cargue los productos existentes en el ComboBox de producto.
- Compras cargue los productos existentes en el ComboBox de producto.
- Proveedores cargue proveedores en su ComboBox de compras.
- Producto muestre nombre, stock y precio en los ComboBox.
- Cliente muestre nombre y DNI en el ComboBox.
- Si la base de datos está vacía, se crean datos iniciales de categorías, marcas, tallas, productos, clientes y proveedores.
- Los datos iniciales solo se insertan cuando la tabla correspondiente está vacía; no se borran los datos existentes.
- Después de registrar una venta se vuelve a cargar la lista de productos para reflejar el stock actualizado.

Importante: la pestaña Proveedores es para registrar proveedores. La selección de producto corresponde a la pestaña Compras, donde se elige proveedor + producto.

Para probar:
1. Ejecutar el proyecto.
2. Iniciar sesión con admin / 1234.
3. Abrir Operaciones.
4. En Carrito y ventas, abrir Producto y comprobar que aparecen productos.
5. En Compras, comprobar que aparecen proveedor y producto.
6. En Proveedores, registrar nuevos proveedores si se necesita.
