# Base de datos de TiendaRopa

Se adaptó el patrón de conexión del proyecto de referencia SysVentas usando H2 y JDBC.

## ¿Qué se añadió?
- H2 en `pom.xml`.
- `DatabaseConfig.java` para conectar y crear tablas al iniciar.
- Tablas `categoria`, `marca`, `producto`, `cliente` y `usuario`.
- Repositorios JDBC para que las operaciones CRUD guarden datos en la base y no solo en ArrayList.
- Inicio de sesión validado contra la tabla `usuario`.
- `schema_tiendaropa.sql` como documentación del modelo de datos.

## Ejecutar
1. Abrir la carpeta del proyecto en IntelliJ IDEA.
2. Esperar a que Maven descargue H2.
3. Ejecutar `MainApp` o `mvn clean javafx:run`.
4. Usuario inicial: `admin`; contraseña inicial: `1234`.
5. La base se crea en `data/tiendaropa.mv.db` al iniciar.

## Tablas y relaciones
- `categoria` 1 a N `producto`.
- `marca` 1 a N `producto`.
- `usuario` almacena las cuentas habilitadas para ingresar.
- `cliente` guarda el DNI y datos de contacto.

Nota académica: la contraseña de ejemplo se guarda como texto plano para mantener el ejemplo sencillo; en un sistema real debe almacenarse con hash seguro. El archivo H2 se crea en la carpeta desde la que se ejecuta el programa.
