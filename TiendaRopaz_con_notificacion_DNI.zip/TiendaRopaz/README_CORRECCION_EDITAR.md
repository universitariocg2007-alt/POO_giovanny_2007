# Corrección de los botones Editar

Se corrigieron los CRUD de Categoría, Marca, Cliente y Producto.

## Cambio principal
Cada controlador guarda el ID del registro seleccionado en `idEditando`. El botón **Editar** construye la entidad con ese ID y ejecuta `UPDATE ... WHERE id=?`.

## Protección contra duplicados
Mientras existe un registro en edición, el botón **Guardar** no permite crear otro registro y muestra un aviso indicando que se debe usar **Editar**.

## Flujo correcto
1. Seleccionar una fila de la tabla.
2. Modificar los datos en los campos.
3. Presionar **Editar**.
4. El registro conserva su mismo ID; solo cambian sus datos.
5. Después de actualizar se limpian los campos y se recarga la tabla.

También se mejoró la selección de Categoría y Marca al editar un producto para que se seleccionen por ID.

## Verificación
Se revisaron los archivos Java y las referencias FXML de los cuatro formularios. El entorno de esta revisión no dispone del comando Maven (`mvn`), por lo que no se puede afirmar una ejecución Maven completa aquí.
